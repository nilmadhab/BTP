for($w=15; $w <=50 ; $w=$w+5)
{
	system("perl generate.pl $w 160 1");
	#print "done";
}
