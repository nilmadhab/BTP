
ITC'02 SOC TEST BENCHMARKS
==========================


This directory contains the ITC'02 SOC Test Benchmarks.

The format of these benchmarks is explained at
http://www.extra.research.philips.com/itc02socbenchm/

The following benchmarks are included.

     u226.soc
     d281.soc
     d695.soc
     h953.soc
    g1023.soc
    f2126.soc
   q12710.soc
   p22810.soc
   p34392.soc
   p93791.soc
  t512505.soc
  a586710.soc


EJM

