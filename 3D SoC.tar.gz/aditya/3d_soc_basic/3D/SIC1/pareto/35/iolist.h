#define TAM_WIDTH_MAX 35
#define BIT_LENGTH 6
#define TSV_MAX 140
#define NCores 5
#define TAM {31,12,31,25,31}
#define TAMSUM 130