#define TAM_WIDTH_MAX 50
#define BIT_LENGTH 6
#define TSV_MAX 140
#define NCores 5
#define TAM {46,12,46,25,46}
#define TAMSUM 175