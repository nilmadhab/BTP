#define TAM_WIDTH_MAX 30
#define BIT_LENGTH 5
#define TSV_MAX 140
#define NCores 5
#define TAM {26,12,26,25,26}
#define TAMSUM 115