#define TAM_WIDTH_MAX 15
#define BIT_LENGTH 4
#define TSV_MAX 140
#define NCores 5
#define TAM {11,10,11,11,11}
#define TAMSUM 54