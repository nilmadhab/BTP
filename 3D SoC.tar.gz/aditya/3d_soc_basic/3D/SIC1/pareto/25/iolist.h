#define TAM_WIDTH_MAX 25
#define BIT_LENGTH 5
#define TSV_MAX 140
#define NCores 5
#define TAM {21,12,21,21,21}
#define TAMSUM 96