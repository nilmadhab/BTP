#define TAM_WIDTH_MAX 45
#define BIT_LENGTH 6
#define TSV_MAX 140
#define NCores 5
#define TAM {41,12,41,25,41}
#define TAMSUM 160