#define TAM_WIDTH_MAX 40
#define BIT_LENGTH 6
#define TSV_MAX 140
#define NCores 5
#define TAM {36,12,36,25,36}
#define TAMSUM 145